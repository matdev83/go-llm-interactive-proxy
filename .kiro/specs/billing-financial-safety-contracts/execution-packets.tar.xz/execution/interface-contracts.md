# Interface and transition contracts

Normative supplement to design D03-D14. These are proposed additive contracts, not assertions that these symbols already exist. Use existing Money, VersionRef, canonical call/event, economics and metering types; do not create a second set of pricing algorithms. External SDK definitions may not import internal packages. Internal adapters must perform lossless field-by-field conversion with equality tests.

## A1. Required value shapes

| Value | Required fields and constraints |
|---|---|
| FinancialContract | ID=`all-attributable-pessimistic/v1`; selection=all_attributable; output_policy=catalog_first; client_fallback_enabled defaultfalse; no implicit subsidies; versioned fee/rounding rules |
| EconomicRequestBounds | trusted StoreID, AccountID, RootSubmissionID, CallID, ParentCallID when child; BackendID, ModelID, ProviderAccountRef, Family; EconomicDigest; MaterialRefs; InputBound/proof; ReservationOutputMax; TransmittedOutputCap; OutputBoundSource; CandidateCount; CacheTreatment/TTL; finite typed DimensionBounds; scope-correct fee bindings |
| DimensionBound | canonical metering ComponentKey with unit, direction and qualifiers; finite nonnegative exact rational quantity upper bound; proof ID and enforcement ID; presence state; no arbitrary string-name price inference |
| FrozenMaterialRef | kind, ID, version, SHA256 content hash; canonical body stored once durably; immutable reference to a model, tariff, policy, schema, family proof or execution plan |
| ExecutionEnvelope | ID, RootSubmissionID, CallID, account; finite ordered Slot[]; scoped fees; attempt ceiling; parent lineage; content hash; launch_set_open boolean; slots contain deterministic SlotID, matching family/model/shape, multiplicity=1, Q, future-input bound, state |
| BoundQuote | ID, contract/material refs, envelope and economic digest, customer/supplier upper amounts, input/fixed bound, max-output source/cap, component breakdown, dominance proof; validated checked one-currency amounts |
| CapacityReceipt | opaque ID, host/store/process incarnation, envelope hash, finite byte/record reservation and durable descriptor key; must already be durably accepted before root authorization |
| DispatchGrant | opaque 128-bit random ID; one OperationID; account/call/B-leg/SlotID/DispatchID; prepared digest/quote/material refs; Epoch, process incarnation, issued/expiry monotonic lease binding; central state and persisted expiry; never client-issued |
| DurableAcceptance | obligation ID, immutable payload/manifest hash, accepted durable version; success is permitted only after commit, not merely after queue push |
| RecognitionInput | charge identity/revision/predecessor, observation refs/input-set hash, frozen tariff, validated valuation, delta C, own old allocation and proven residual, worker lease/fence; no caller-only amount authority |
| RecognitionResult | journal and collection operation IDs, B/D/R before/after, recognized delta, collected delta, unpaid delta, residual, breach flag, account epoch/freeze event; worker must consume breach rather than discard it |
| ReconciliationCase | immutable case key, account/obligation refs, finite reason, first_seen/last_seen/next_due, named owner=billing-reconciliation, expected evidence and repair code, source hashes, audit operation IDs; pending is not a final write-off |

Scopes are checked against trusted host identity. ID string equality alone is insufficient without matching store/account/contract/material/epoch. Avoid pointers into mutable request maps. Every returned value is detached or an opaque immutable owned handle.

## A2. Narrow ports

Use these method names and semantics. Existing equivalent concrete methods may implement them through an additive adapter; do not rename unrelated production APIs. Context is the first argument. Inputs/results are the typed values above with errors preserving typed cause.

| Port / owning zone | Methods | Atomicity and failure contract |
|---|---|---|
| PaidPreparer / SDK, implemented by backend | PreparePaid(ctx, CallOrBodyHandle, TrustedEconomicContext) -> PreparedPaidRequest; SendPrepared(ctx, PreparedPaidRequest, DispatchGrant) -> ManagedEventStream | Prepare is side-effect-free except explicitly funded child work; same immutable representation is sent once; no ordinary Open fallback in strict mode |
| PreparedPaidRequest / SDK | Facts() -> EconomicRequestBounds; Digest() -> string; Close() -> error | Facts detached; body encoding/resource ownership stays backend-local; Close idempotent; no post-authorization mutation |
| FinancialFunding / core consumed at runtime | AdmitRoot(ctx, RootFundingInput) -> RootFundingReceipt; AllocateDispatch(ctx, DispatchFundingInput) -> DispatchGrant; ConsumeDispatch(ctx, GrantConsumptionInput) -> AuthorizedDispatch; ReadOperation(ctx, scoped OperationID) -> FundingOperationResult | Central account transaction; no paid send on ambiguous commit ACK; duplicate consumption never grants another send |
| FinancialTerminal / core and SDK binding | AcceptEvidence(ctx, FinancialEvidenceInput) -> DurableAcceptance; SealFinancialCall(ctx, CallClosureInput) -> DurableAcceptance | Durable acceptance before success; independent of stream CAS; closure launch set comes from durable allocations |
| FinancialFences / core and SDK binding | FreezeAccount(ctx, FreezeInput) -> FreezeResult; ReadFinancialEpochs(ctx, ActiveAccountBatch) -> EpochBatch; SubscribeFenceWakeups(ctx, consumer) -> owned subscription | Freeze is part of failing funding/recognition tx; read durable epoch is authority, wakeup not authority; independent subscribers |
| FinancialReconciliation / core store worker | ClaimFinancialWork(ctx, ClaimInput) -> bounded ClaimedWork[]; CompleteClaim(ctx, FencedResult) -> result; RetryClaim(ctx, FencedRetry) -> result; ImportRepair(ctx, AuthenticatedRepairInput) -> result | Stable work key/fence, durable due time, no transient lifetime cap; only proven evidence repairs |
| FinancialHealth / host | ReadFinancialHealth(ctx) -> bounded HealthReport | Used to refuse new liability when durable or control prerequisites fail; admitted debt still processed |

RootFundingInput includes the complete quote/envelope/capacity receipt and trusted principal. DispatchFundingInput includes the frozen prepared facts and unused slot or explicit increment; it names whether the extension is required ongoing work. GrantConsumptionInput includes expected epoch/incarnation/digest. An AuthorizedDispatch is one use by the managed runtime, not a transferable permission to call raw Open.

SDK BindingVersionV2 adds the required ports to the existing single binding. No second billing authority or mutable global registry is introduced. Strict host validation is unconditional; legacy v1 exists only for its explicit non-strict/historical path. Compiler changes must remain additive to ordinary backend Open.

## A3. Central state transitions

| Prior state | Operation and preconditions | Next state / retained liability |
|---|---|---|
| absent root | durable local capacity, frozen materials, H>=Q, account READY | funded envelope; R+=Q; double-sided operational reserve |
| unused slot | final prepared facts fit slot and same account/epoch | allocated dispatch; R unchanged; operational transfer |
| absent extra slot | required fresh Q increment fits H | allocated new dispatch; R+=Q increment |
| active call, insufficient required increment | authenticated ongoing-work marker; current account transaction | account frozen, epoch advanced, cancellation event; no new send |
| allocated dispatch | one central consume matching prepared digest/epoch/incarnation | authorized_unknown; funded before any network write |
| authorized_unknown | provider acceptance/receipt, possibly after timeout | accepted/evidence_pending; full unrecognized residual retained |
| authorized_unknown | explicit proof SendPrepared never invoked, owner lease ended, no side effect and sealed launch set | resolved zero inference; audited unused release |
| accepted/pending | valid partial source revision | known recognition work; retain unknown dimensions/residual |
| accepted/pending | complete certified final usage and fee-tail evidence | final recognition work; release only unused remainder atomically |
| any unresolved | invalid/missing evidence, first append failure, lost owner | reconciliation/evidence pending with retained descriptor and bounds |
| claimed work | valid result with current worker fence | journal/projection/pin/work commit together; exactly-once effect |
| claimed work | transient error | persisted next retry or recoverable stale claim; never processed |
| frozen account | validated incurred charge/correction/deposit | accounting allowed; no new dispatch; resume requires separate action |

No state transition infers zero from TTL, cancellation, process shutdown or missing data. A stream terminal state and financial state may legitimately differ. Different B-legs with a proved same provider charge share its economic head, while keeping all lineage references.

## A4. Keys, constraints and deterministic bounded defaults

Use scoped, versioned keys such as `fs:v1:<store>:<account>:<dispatch>:recognition:<source-revision>` and distinct `...:collection:<collection-operation-id>`; stable components must be validated/encoded unambiguously rather than concatenated from unchecked strings. Provider external IDs are scoped by provider account and charge kind. Prefer canonical hashing of a typed preimage over delimiter assumptions. Duplicate key plus different fingerprint is conflict.

Unique constraints: envelope(account,call); slot(envelope,slot); dispatch(store,dispatch); operation(store,account,operation_id); scoped provider-charge head; recognition(head,source_revision); exposure operation(key); capacity receipt(key). All foreign-key/scope checks include the owning store/account where needed. Existing journal/pin uniqueness remains authoritative, not bypassed by a second strict table. Financial rows must remain traceable to immutable observations/materials.

Backoff 1s capped 60s DB/1h provider-pending; full jitter; worker lease 30s; recovery page 128; economic batch 32/concurrency 4; spool flusher 1; fresh admission queue 1024/process; completion/control lanes 256 each; control poll 200ms/query deadline 200ms; per-process active-account control capacity 1024, checked before admission; account authority lease<=1s. These are bounded defaults, not throughput promises. A control lane that cannot renew its served set in time loses authority and cancels; do not extend the lease to hide overload. Every limit is validated positive with checked sizing arithmetic and reported in gate receipts.

Reserved spool footprint per dispatch: maximum terminal envelope 1MiB plus descriptor 8KiB, chunk size 64KiB, manifest 8KiB; root descriptor 8KiB plus 8KiB per planned slot. Enforce a maximum of 32 chargeable components and 128 immutable observation references in this initial strict terminal envelope. An adapter needing more declares a larger finite capability footprint before admission; without one the affected shape is unsupported, not truncated. Capacity checks reserve 2x payload budget for database/WAL headroom plus the existing configured free-disk reserve. Count all reserved/error/delivering occupancy. Runtime cannot silently enlarge footprint after dispatch. Preserve overflow evidence as a visible pending/reconciliation condition and financial bound.

These footprint figures are engineering safety ceilings selected here, not provider billing facts. Existing supported standard text fixtures must fit; receipt tests deliberately exceed a bound to verify preservation/refusal. Do not reinterpret a deterministic local storage budget as a hard bound on all possible operating-system disk behavior.


## Revision 2 additive media and joint-contract binding

The complete normative multimodal values, method semantics, receipt and coverage contracts are in [coverage/contracts.md](../coverage/contracts.md), embedded in every affected packet. Extend the unimplemented BindingV2 and prepared-request/grant contracts with the entire media occurrence, output plan and joint economic contract digests. Do not create a second authority or reinterpret sparse native units as text. Module ABI consumers are owned by14.1 and each module packet.
