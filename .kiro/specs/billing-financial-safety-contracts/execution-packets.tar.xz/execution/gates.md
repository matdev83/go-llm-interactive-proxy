# Executable gate contract

This file defines the exact **new** gate behavior to implement in task 9.4. `tools/billing-safety` and `make billing-safety-*` are proposed deliverables, not commands claimed to exist at the reviewed baseline. Existing canonical commands remain authoritative in the repository Makefile.

## Task-local test naming

Every task adds at least one assertion-bearing test named `TestFinancialSafety_Tnn_<case>`, where Tnn is its manifest packet ID. The supplied Python `tools/run_task_gate.py` executes that task's specified packages and reads go-test JSON. At least one matching top-level test must run and pass; zero matches, skipped matching tests or a failed package is failure. A local task does not need to rerun all 112 final scenarios; it implements its listed boundary cases. Final scenarios use names `TestFinancialSafety_Snn_<case>` and a machine result index. Broad/nested package names must not cause unrelated modules to be recursively rebuilt.

## Topologies and mandatory scenario selection

All 112 scenarios require a hermetic/domain/family fixture or the explicit topology named in the scenario manifest. Every persistence scenario must additionally run against file-backed SQLite and PostgreSQL-direct; the distributed subset requires two real processes sharing PostgreSQL. The pooled subset runs through a transaction pooler while migrations use a direct admin connection. Mandatory topology invocation without service/connectivity/permissions fails at setup, not t.Skip.

New gate environment names: `BILLING_SAFETY_PG_DSN` and `BILLING_SAFETY_PGBOUNCER_DSN` carry runtime connections; `BILLING_SAFETY_ADMIN_DSN` is direct migration-only; `BILLING_SAFETY_ARTIFACT_DIR` is an isolated output directory. DSNs must not appear in receipts/logs. Existing dbparity configuration remains unchanged; the gate adapter may translate a supplied value to the repository's existing testkit configuration without adding session state.

New targets: `make billing-safety-unit`, `make billing-safety-sqlite`, `make billing-safety-postgres`, `make billing-safety-pooler`, `make billing-safety-release`. Each invokes the new runner with the immutable acceptance manifest and writes a topology-specific result containing actual code SHA, scenario names, tests run/pass/fail/skip, topology, configuration bounds, raw-log hashes and independent monetary counters. No target returns success if its required scenario set is incomplete. Tests do not fabricate a completed receipt merely by reading a list of desired names.

## Five fixed real-stack sentinels

1. OpenAI Chat frontend -> Anthropic backend: full-miss cache write and sparse usage.
2. Anthropic frontend -> OpenAI Responses backend: text completion with inclusive reasoning, plus 402 rejection.
3. Gemini frontend -> OpenAI Chat backend: cap translation and cancelled/failed usage preservation.
4. OpenAI Responses frontend -> Gemini backend: finite thinking/candidate bounds and evidence-pending error.
5. OpenResponses frontend -> OpenResponses-compatible backend: canonical extensions, hidden thinker continuation and financial error framing.

Run each streaming and collected non-streaming. Add one large-body/wire admission-denial and one successful funded wire request through every frontend's existing wire entrypoint; where a frontend has no distinct wire path, prove it uses canonical entry rather than skipping its monetary contract. Family-local TCKs supplement the complete generated matrix in D23. No new pairwise translators are allowed, but exhaustive cross-interface signature verification is mandatory in the release lane.

## Fault hooks and exact crash points

Use these test-only hooks, with sidecar provider counters outside the killed process: capacity_committed; root_commit_before_ack; dispatch_allocated; grant_commit_before_ack; provider_accepted_before_stream; usage_received_before_spool_commit; spool_committed_before_central_ack; central_evidence_committed_before_queue_ack; recognition_committed_before_worker_ack; freeze_committed_before_wakeup; lease_reassigned_before_old_ack. All crash cases preserve reserved liability or recognized debt and never blindly repeat a paid request. A fixture must assert the hook really fired.

## Required negative mutations

In isolated disposable copies, deliberately: bypass managed grant consumption; replace catalog max with smaller user cap; omit cache-write cost; reset attempt budget; drop a timeout as NeverStarted; suppress billing after quota error; restore 20-attempt abandonment; consume sibling funds on an overrun; drop a first-enqueue recovery descriptor; ignore fence epoch; omit a connector proof; downgrade a strict exposure to legacy owner. Every mutation must make its corresponding independent test fail. Remove the mutations before any delivery. No network credentials or live provider billing is needed for these tests.

## Final release receipt

The final candidate must pass the new release runner plus existing `make quality-checks`, `make test`, `make parity-checks`, `make test-db-parity`, and `make qa`, as well as targeted Linux race tests for runtime/store/registry lifecycle. When test infrastructure/cost changes affect Windows budgets, run `make test-cost` without overrides. Retain actual unrelated baseline failures separately, but do not present an unexecuted mandatory financial gate as complete.

One receipt entry per required scenario/topology includes: test IDs, actual pass/fail/skip, provider accepted/send/receipt counts, recognized retail, collected amount, debt, R, COGS/payable totals, independent journal equality, and unresolved reason where expected by the scenario. Tests of permanent missing evidence pass only by proving visible funded pending state, never a fabricated final charge. Tests injecting supplier overbilling pass containment assertions but do not certify that violated external contract as a normal no-overspend success.


## Revision 2 mandatory coverage gates

The original cross-family examples are fast sentinels, not the full release denominator. Tasks 15.1-15.5 verify every interface pair, all input/output masks and every actual profile/operation/carrier/mode expansion. A required positive cell needs real native-wire invocation and balanced settlement evidence. A negative needs an independently justified native or inherent-unbounded predicate plus zero payable dispatches. Missing implementation, pricing or test infrastructure is a blocker.

Specification-only checks: `python tools/verify_spec.py`, `python tools/verify_coverage.py`, `python tools/verify_coverage.py --self-test`, and `python tools/run_task_gate.py --self-test` from the appropriate specification root. These check artifacts and synthetic validators, not the proxy. `coverage_lattice.py` emits NOT_RUN obligations only.

Run module packets 14.2-14.35 from their manifest working directory through the supplied gate wrapper. Mandatory final media durability tests use file-backed SQLite, PostgreSQL-direct and actual multiple processes; normal in-memory fixtures do not replace them. Release requires the actual external topology instead of silently skipping.

Every packet embeds hashes of its canonical design sections and requirements. Any upstream edit requires packet regeneration and complete validation before more implementation. Stale packet text is not an alternate source of truth.
